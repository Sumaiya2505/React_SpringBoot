import React, { useState } from "react";
import { Component } from "react";
import Carousel from 'react-bootstrap/Carousel';
import '../css/Productcss.css';
import image1 from '../Assets/iphone15b1.jpg';
import image2 from '../Assets/iphone15b3.png';
import image3 from '../Assets/iphone1 (1).jpg';
import Button from 'react-bootstrap/Button';
import Ratings from './Ratings';
import { FaUserCircle } from "react-icons/fa";

function Product({datalist})
{
  const[state,setState]=useState(false);
  const[state1,setState1]=useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoading1, setIsLoading1] = useState(false);
  const handleClick = () => {
    setState(true);
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
    }, 5000); 
  };
  const handleClick1 = () => {
    setState1(true);
    setIsLoading1(true);
    setTimeout(() => {
      setIsLoading1(false);
    }, 5000); 
  };
  return (
    <>  
    <table  className="td" >
        <tr>
            <td>
    <Carousel data-bs-theme="dark" className="size" >
      <Carousel.Item>
        <img
          className="d-block w-100"
          src={image1}
        />
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src={image2}
        />
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src={image3}
          alt="Third slide"
        />
      </Carousel.Item>
    </Carousel>
    </td>
    <td>
    <h3>Apple iPhone 15 Pro Max (256 GB) - Black Titanium</h3>
    <h2> $1774.89</h2>
    <br/>
    <table className="proddettab">
        <thead>
            <tr>
            <th style={{width:'110px'}}>Brand</th>
            <th style={{width:'450px',fontWeight:'normal'}}>Apple</th>
            </tr>
        </thead>
        <tbody style={{width:'110px'}}>
        <tr>
            <td><b>Model Name</b></td>
            <td>iPhone 15 Pro Max</td>
        </tr>
        <tr>
            <td><b>Network Service Provider</b></td>
            <td>Unlocked for All Carriers</td>
        </tr>
        <tr>
            <td><b>Operating System</b></td>
            <td>iOS</td>
        </tr>
        <tr>
            <td><b>Cellular Technology</b></td>
            <td>5G</td>
        </tr>
        </tbody>
    </table>
    <br/>
    <br/>
    <Button className="button"> Add to Cart</Button>
    <br/>
    <br/>
    <Button className="button">Buy Now</Button>
    </td>
    </tr>
    </table>
    <table>
      <tr><td><Button style={{marginRight:'5px'}} onClick={handleClick}  disabled={isLoading} id="aibutton">Bart Model Review</Button></td>
      <td><Button  onClick={handleClick1}  disabled={isLoading1} id="aibutton">GPT Model Review</Button></td>
      <td><h3 style={{alignContent:'left'}}>Top Reviews</h3></td>
      </tr>
      {/* <tr><td><Button onClick={handleClick1}  disabled={isLoading1} id="aibutton">GPT Model Review</Button></td></tr> */}
    </table>
    <table className="aitable">
    {isLoading &&
          <p>Loading...</p>
    }
    {isLoading1 &&
          <p>Loading...</p>
    }
    { state && !isLoading &&
         
          <tr><td><p><b>Bart Model Summary:</b><br/>The 15 Pro Max doesn't offer a significant leap in terms of innovation. For those already enjoying the perks of the previous Pro models, the upgrade might not feel as compelling. The photos are stunning and spectacular. No heating issues or such.</p></td></tr>
    }
    { state1 && !isLoading1 &&
         
         <tr><td><p><b>GPT Summary:</b><br/>The iPhone 15 Pro Max is a quality mobile phone with a clean operating system and good battery life. It is suitable for moderate use of social media, messaging apps, and multimedia. The camera quality is good and the phone performs well. However, some users find it to be too expensive compared to other phones on the market. It is preferred over the Samsung S24 Ultra in terms of quality and camera. There were some initial reports of overheating issues, but they have been resolved with software updates. Overall, the iPhone 15 Pro Max is a solid device with a stellar camera, but may not offer a significant upgrade for those already using the previous Pro models.<br/><b>Verdict:</b><br/>Based on the reviews, the iPhone 15 Pro Max is a recommended phone for those looking for a quality device with a good camera. However, if you already have the 13 or 14 Pro models, the upgrade may not be necessary.</p></td></tr>
   }
       </table>
       <div className="scroll" >
       <ul className="datatable">
         {datalist.map((item) => (
            <li key={item.id}>
                <FaUserCircle/> {item.name}
                <Ratings star={item.star}/>
                {item.review}
                <br/>
                <br/>
            </li>
        ))}
    </ul>
    </div>
    </>
    );
}
export default Product;