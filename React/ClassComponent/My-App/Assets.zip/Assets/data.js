
const data=[
    {id:1,
    name:'Dinesh',
    star:"4.5",
    review:"As I was aware that what I need and what I was paying for, I needed a quality mobile with best hardware and software combination.I need the OS to be clean without any bloatware which I got.I dont play games. For moderate use of Social media, whatsapp, youtube, audible (audio books), music while exercising, Battery life is around 2 days or sometimes more than 2 days. If you are a gamer or use mobile a lot you might need to charge your mobile everyday.Camera is good. So far the pictures I took the quality is good.Not explore the processor's capacity yet but Never hanged or never will for me not a heavy user so won't be a problem."
    },

    {id:2,
    name:'Rithiba',
    star:"4",
    review:"A phone that screams that you are doing very well for yourself. Don’t get me wrong, it works extremely well and I am completely satisfied with it. but, it is way too expensive for a phone. I have a pixel 8 which as a secondary phone which costs way less and I am satisfied with that as well. Nevertheless, nothing can replace an iPhone for me due to personal preferences."
    },

    {id:3,
    name:'Divya',
    star:"3.5",
    review:"I would prefer this over S24 ultra. Used both phones and impressed by this phone. Yes I agree s24 ultra had few more features but in terms of quality 15 pro max wins. And camera quality is far better than s24ultra. But it differs on a customer’s choice." 
    },

    {id:4,
    name:'Mouresh',
    star:"5",
    review:"The phone is really good it had some overheating issue as heard but not faced any it was due to software update now it is all fixed I still did not had any issue regarding overheating. The phone is really fast and the battery life is awesome. The new action button is really handy and useful. The camera is the best camera an iPhone ever had the photos are stunning and spectacular…. I am satisfied with the phone.."
    },

    {id:5,
    name:'Nandhini',
    star:"4",
    review:"I recently upgraded to the Apple 15 Pro Max, and while the enhanced camera is undoubtedly impressive, but I feel that it falls short of delivering a truly groundbreaking experience. If you're already using the 13 pro or 14 Pro, there seems to be little incentive to make the leap.The camera improvements are noteworthy, capturing detail and clarity like never before. However, beyond this feature, the 15 Pro Max doesn't offer a significant leap in terms of innovation. Personally, I find the Pro versions more manageable in hand, and the Max variant, although boasting a larger screen, can be a bit unwieldy.In essence, the 15 Pro Max is a solid device with a stellar camera, but for those already enjoying the perks of the previous Pro models, the upgrade might not feel as compelling."
    },

    {id:6,
    name:'Ashwin',
    star:"3",
    review:"iphone 15pro max ios worst pro max I purchased. I already have 13 and 14 pro max, Time to switch to Samsung. The screeenshot you see shows 85% baterrey charge but it has been only 5 min after i made a full charge of the phone"
     },

    {id:7,
    name:'Karthik',
    star:"3.5",
    review:"Camera setting not available, so photos not better than Samsung m34, likely Caller tune should not set, call record not available. Should not connect to laptop. Download space not available"
    },

    {id:8,
    name:'Ayana',
    star:"5",
    review:"I recently switched from android to iphone. So i am liking the good audio quality, camera and everything."
    },

    {id:9,
    name:'Harish',
    star:"4",
    review:"I like in this phone best camera.And back glass is not too strong and It is mild then other iphone's"
    },

    {id:10,
    name:'Vishal',
    star:"5",
    review:"It’s a fantastic phone,the feel and comfort in hand is awesome,looks stunning…also the brand appeal of Apple is fabulous. Camera is the best, performance is over the top…really fast and the games you can play are of play station’s…can any other phone do that…also the video quality is very nice"
    },
    
    {id:11,
    name:'Abhi',
    star:"5",
    review:"It’s around 2months I have been using this device and it has been working flawlessly. No heating issues or such. Totally worth the upgrade because of the camera."
    },
]

export default data;