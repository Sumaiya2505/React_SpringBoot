package com.cts.springboot.dao;

import java.util.List;

import com.cts.springboot.entity.Product;

public interface ProductDao {
		
	abstract String addProduct(Product product);
	abstract String updateProduct(Product product);
	abstract String deleteProduct(int productId);
	abstract Product getProductById(int productId);
	abstract List<Product> getAllProducts();
	abstract List<Product> getAllProductsBetweenPrices(int initialPrice,int finalprice);
	abstract List<Product> getAllProductByCategory(String productCategory);
}
