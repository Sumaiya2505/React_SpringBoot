package com.cts.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.springboot.entity.Product;
import com.cts.springboot.service.ProductService;
//@Controller + @ResponseBody
@RestController
@RequestMapping("/products")
public class ProductController 
{
	
	@Autowired
	ProductService productservice;
	
	@PostMapping("/products")
	public String addProduct(@RequestBody Product product)
	{
		return productservice.addProduct(product);
	}
	
	@PutMapping("/updateproduct")
	public String updateProduct(@RequestBody Product product)
	{
		return productservice.updateProduct(product);
	}
	
	@DeleteMapping("/deleteproduct/{id}")
	public String deleteProduct(@PathVariable("id")int productId)
	{
		return productservice.deleteProduct(productId);
	}
	
	@GetMapping("getproduct/{id}")
	public Product getProductById(@PathVariable("id") int productId)
	{
		return productservice.getProductById(productId);
	}
	
	@GetMapping("getallproducts")
	public List<Product> getAllProducts()
	{
		return productservice.getAllProducts();
	}
	
	@GetMapping("getproductsbetween/{iprice}/{fprice}")
	public List<Product> getAllProductsBetweenPrices(@PathVariable("iprice")int initialPrice,@PathVariable("fprice")int finalprice)
	{
		return productservice.getAllProductsBetweenPrices(initialPrice, finalprice);
	}
	@GetMapping("getallproductsbycategory/{category}")
	public List<Product> getAllProductByCategory(@PathVariable("category")String productCategory)
	{
		return productservice.getAllProductByCategory(productCategory);
	}
	
	
	
	
}
