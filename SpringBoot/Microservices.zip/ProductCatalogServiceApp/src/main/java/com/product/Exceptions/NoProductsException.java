package com.product.Exceptions;

public class NoProductsException extends RuntimeException{


	public NoProductsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
}
