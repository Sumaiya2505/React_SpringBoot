package com.cts.springboot1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProjectPracticeUsingH21ApplicationTests {

	@Test
	void contextLoads() {
	}

}
