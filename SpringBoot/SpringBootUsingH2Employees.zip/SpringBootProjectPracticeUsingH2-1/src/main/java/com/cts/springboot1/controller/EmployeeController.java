package com.cts.springboot1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.springboot1.entity.Employee;
import com.cts.springboot1.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	

	@Autowired
	EmployeeService employeeservice;
	
	
	@PostMapping("/addemployee")
	public String addEmployee(@RequestBody Employee emp)
	{
		return employeeservice.addEmployee(emp);
	}
	
	@PutMapping("/updateemployee")
	public String updateEmployee(Employee emp)
	{
		return employeeservice.updateEmployee(emp);
		
	}
	
	@DeleteMapping("/deletebyid/{id}")
	public String deleteEmployee(@PathVariable("id")int empId)
	{
		return employeeservice.deleteEmployee(empId);
	}
	
	@GetMapping("/getemployeebyid/{id}")
	public Employee getEmployeeById(@PathVariable("id")int empId)
	{ 
		return employeeservice.getEmployeeById(empId);
		
	}
	
	@GetMapping("/getemployees")
	public List<Employee> getAllEmployees()
	{
		return employeeservice.getAllEmployees();
	}
	
	@GetMapping("/getemployeesbetwwensalary/{in}/{fin}")
	public List<Employee> getAllEmployeeBetweenSalary(@PathVariable("in")int initialsalary,@PathVariable("fin")int finalsalary)
	{
		return employeeservice.getAllEmployeeBetweenSalary(initialsalary, finalsalary);
	}
	
	@GetMapping("/getallemployeesbydesignation/{desig}")
	public List<Employee> getAllEmployeeByDesignation(@PathVariable("desig")String designation)
	{
			return employeeservice.getAllEmployeeByDesignation(designation);
	}

}
