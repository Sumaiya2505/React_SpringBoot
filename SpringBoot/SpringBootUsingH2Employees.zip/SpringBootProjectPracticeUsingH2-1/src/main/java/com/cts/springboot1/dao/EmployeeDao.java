package com.cts.springboot1.dao;

import java.util.List;

import com.cts.springboot1.entity.Employee;



public interface EmployeeDao {

	abstract String addEmployee(Employee emp);
	abstract String updateEmployee(Employee emp);
	abstract String deleteEmployee(int empId);
	abstract Employee getEmployeeById(int empId);
	abstract List<Employee> getAllEmployees();
	abstract List<Employee> getAllEmployeeBetweenSalary(int initialsalary,int finalsalary);
	abstract List<Employee> getAllEmployeeByDesignation(String designation);
	
	
	
	
	
	
}
