package com.cts.springboot1.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cts.springboot1.entity.Employee;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {

	@PersistenceContext
	EntityManager entitymanager;
	
	@Override
	public String addEmployee(Employee emp) 
	{
		entitymanager.persist(emp);
		return "Employee added successfully";
	}

	@Override
	public String updateEmployee(Employee emp) 
	{
		entitymanager.merge(emp);
		return "Employee updated successfully";
	}

	@Override
	public String deleteEmployee(int empId) 
	{
		entitymanager.remove(getEmployeeById(empId));
		return "Employee deleted successfully"; 
	}

	@Override
	public Employee getEmployeeById(int empId) 
	{
			return entitymanager.find(Employee.class, empId);
	}

	@Override
	public List<Employee> getAllEmployees() 
	{
		TypedQuery<Employee> emp =entitymanager.createQuery("select e from Employee e",Employee.class);
		return emp.getResultList();
	}

	@Override
	public List<Employee> getAllEmployeeBetweenSalary(int initialsalary, int finalsalary) 
	{
		TypedQuery<Employee> emp =entitymanager.createQuery("select e from Employee e e.salary between 1? and 2?",Employee.class);
		emp.setParameter(1, initialsalary);
		emp.setParameter(2, finalsalary);
		return emp.getResultList();
		
	}

	@Override
	public List<Employee> getAllEmployeeByDesignation(String designation) 
	{	
		TypedQuery<Employee> emp =entitymanager.createQuery("select e from Employee e where e.designation=1?",Employee.class);
		emp.setParameter(1, designation);
		return emp.getResultList();
		
	
	}

}
