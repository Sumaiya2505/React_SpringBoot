package com.cts.springboot1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.springboot1.dao.EmployeeDao;
import com.cts.springboot1.entity.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService 
{
	@Autowired
	EmployeeDao dao;
	
	@Override
	public String addEmployee(Employee emp) {
		
		return dao.addEmployee(emp);
	}

	@Override
	public String updateEmployee(Employee emp) {
		
		return dao.updateEmployee(emp);
	}

	@Override
	public String deleteEmployee(int empId) 
	{
		return dao.deleteEmployee(empId);
	}

	@Override
	public Employee getEmployeeById(int empId) {
		
		return dao.getEmployeeById(empId);
	}

	@Override
	public List<Employee> getAllEmployees() {
		
		return dao.getAllEmployees();
	}

	@Override
	public List<Employee> getAllEmployeeBetweenSalary(int initialsalary, int finalsalary) 
	{
		
		return dao.getAllEmployeeBetweenSalary(initialsalary, finalsalary);
	}

	@Override
	public List<Employee> getAllEmployeeByDesignation(String designation) {
		
		return dao.getAllEmployeeByDesignation(designation);
	}

}
