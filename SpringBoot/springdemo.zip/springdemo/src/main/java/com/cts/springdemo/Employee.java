package com.cts.springdemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("emp")
public class Employee {

			private int employeeId;
			private String employeeName;
			private int salary;
			@Autowired
			private Address add;
			
			public Address getAdd() {
				return add;
			}

			public void setAdd(Address add) {
				this.add = add;
			}

			public int getEmployeeId() {
				return employeeId;
			}
			
			public void setEmployeeId(int employeeId) {
				this.employeeId = employeeId;
			}
			public String getEmployeeName() {
				return employeeName;
			}
			public void setEmployeeName(String employeeName) {
				this.employeeName = employeeName;
			}
			public int getSalary() {
				return salary;
			}
			public void setSalary(int salary) {
				this.salary = salary;
			}

			public Employee(int employeeId, String employeeName, int salary) {
				super();
				this.employeeId = employeeId;
				this.employeeName = employeeName;
				this.salary = salary;
			}

			public Employee() {
				super();
				// TODO Auto-generated constructor stub
			}
			
			
	
	
}
