package com.cts.springdemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
@ComponentScan("com.cts.springdemo")
@Configuration
public class App 
{
    public static void main( String[] args )
    {
    	
//      Configuration file:xml,annotation,java.
    	
//   1st type Configuration using xml: 
//    	ApplicationContext content = new ClassPathXmlApplicationContext("springconfig.xml");
    	
//    	----for Container based Object Creation,we need to create an xml file called springcomfig.xml and mention the classes for which the object has to be created.
    	
//   2nd Type Configuration using Annotaion:	The below done code for annotation based object creation,where u no need to create the configuration file ,u will be using the annotation
//    	@Component----wherever this annotation is mentioned ,the container will create the object automatically
//      @ComponentScan(package name)----this will scan the entire package and check classes where the @Component is mentioned ,in order to create the Object.
//      @Configuration----- this annotation is used whereever you call the object that is configuring it.

//    	ApplicationContext context = new AnnotationConfigApplicationContext(App.class);
//    	Employee emp = (Employee)context.getBean("emp");
//        System.out.println( emp );
    	
    	
//    	ApplicationContext context = new AnnotationConfigApplicationContext(App.class);
//    	Employee emp = (Employee)context.getBean("emp");
//        System.out.println( emp );
//        System.out.println(emp.getAdd());
        
        
//        example for 2nd type Configuration that is annotation based;
        ApplicationContext app = new AnnotationConfigApplicationContext(App.class);
        Student stu = (Student) app.getBean("Student");
        System.out.println(stu);
        
    }
    
//    3rd Type Configuration that is Java Configuration ,when can implement java configuration using @Bean :
    
//   @Bean("employee") 
//    public Employee getEmployee() 
//    {
//    	return new Employee();
//    }
   
//    Example for 3rd type of Configuration that is Java Configuration
   @Bean("Student")
   public Student getStudent() 
   {
	   return new Student();
   }
   
//  Parent ----- @Component
// Child -------@Service    @Repository   @Controller
}
