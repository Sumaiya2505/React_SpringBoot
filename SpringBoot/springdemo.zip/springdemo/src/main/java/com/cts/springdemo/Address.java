package com.cts.springdemo;

import org.springframework.stereotype.Component;

@Component
public class Address {

	private int houseno;
	private int streetname;
	private int place;
	public int getHouseno() {
		return houseno;
	}
	public void setHouseno(int houseno) {
		this.houseno = houseno;
	}
	public int getStreetname() {
		return streetname;
	}
	public void setStreetname(int streetname) {
		this.streetname = streetname;
	}
	public int getPlace() {
		return place;
	}
	public void setPlace(int place) {
		this.place = place;
	}
	public Address(int houseno, int streetname, int place) {
		super();
		this.houseno = houseno;
		this.streetname = streetname;
		this.place = place;
	}
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
