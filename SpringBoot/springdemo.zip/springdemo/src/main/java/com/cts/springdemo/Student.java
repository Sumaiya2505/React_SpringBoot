package com.cts.springdemo;

import org.springframework.stereotype.Component;

@Component("Student")
public class Student {

	private int studentId;
	private String  studentName;
	private int phoneNo;
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public int getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(int phoneNo) {
		this.phoneNo = phoneNo;
	}
	public Student(int studentId, String studentName, int phoneNo) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.phoneNo = phoneNo;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
